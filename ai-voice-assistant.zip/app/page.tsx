"use client"

import type React from "react"

import { useState, useEffect, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Badge } from "@/components/ui/badge"
import { Mic, MicOff, Volume2, VolumeX, Play, SkipForward, SkipBack, MessageSquare, History } from "lucide-react"
import { useChat } from "ai/react"

interface Message {
  id: string
  role: "user" | "assistant"
  content: string
  timestamp: Date
  type?: "voice" | "text"
}

export default function AIVoiceAssistant() {
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [speechSupported, setSpeechSupported] = useState(false)
  const [recognition, setRecognition] = useState<any>(null)
  const [synthesis, setSynthesis] = useState<SpeechSynthesis | null>(null)
  const [chatHistory, setChatHistory] = useState<Message[]>([])
  const [currentTranscript, setCurrentTranscript] = useState("")

  const { messages, input, handleInputChange, handleSubmit, isLoading } = useChat({
    api: "/api/chat",
    onFinish: (message) => {
      // Speak the assistant's response
      if (synthesis && message.role === "assistant") {
        speakText(message.content)
      }
    },
  })

  const recognitionRef = useRef<any>(null)

  useEffect(() => {
    // Initialize speech recognition and synthesis
    if (typeof window !== "undefined") {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
      const speechSynthesis = window.speechSynthesis

      if (SpeechRecognition) {
        const recognition = new SpeechRecognition()
        recognition.continuous = true
        recognition.interimResults = true
        recognition.lang = "en-US"

        recognition.onstart = () => {
          setIsListening(true)
        }

        recognition.onresult = (event: any) => {
          let transcript = ""
          for (let i = event.resultIndex; i < event.results.length; i++) {
            transcript += event.results[i][0].transcript
          }
          setCurrentTranscript(transcript)

          // If the result is final, process the command
          if (event.results[event.results.length - 1].isFinal) {
            processVoiceCommand(transcript.trim())
            setCurrentTranscript("")
          }
        }

        recognition.onerror = (event: any) => {
          console.error("Speech recognition error:", event.error)
          setIsListening(false)
        }

        recognition.onend = () => {
          setIsListening(false)
        }

        setRecognition(recognition)
        recognitionRef.current = recognition
        setSpeechSupported(true)
      }

      if (speechSynthesis) {
        setSynthesis(speechSynthesis)
      }
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop()
      }
    }
  }, [])

  const startListening = () => {
    if (recognition && !isListening) {
      recognition.start()
    }
  }

  const stopListening = () => {
    if (recognition && isListening) {
      recognition.stop()
    }
  }

  const speakText = (text: string) => {
    if (synthesis) {
      // Cancel any ongoing speech
      synthesis.cancel()

      const utterance = new SpeechSynthesisUtterance(text)
      utterance.rate = 0.9
      utterance.pitch = 1
      utterance.volume = 1

      utterance.onstart = () => setIsSpeaking(true)
      utterance.onend = () => setIsSpeaking(false)
      utterance.onerror = () => setIsSpeaking(false)

      synthesis.speak(utterance)
    }
  }

  const stopSpeaking = () => {
    if (synthesis) {
      synthesis.cancel()
      setIsSpeaking(false)
    }
  }

  const processVoiceCommand = async (command: string) => {
    const lowerCommand = command.toLowerCase()

    // Handle specific commands
    if (lowerCommand.includes("play") && lowerCommand.includes("youtube")) {
      const query = command.replace(/play|on youtube/gi, "").trim()
      handleYouTubeCommand(query)
      return
    }

    if (lowerCommand.includes("next slide")) {
      handleSlideCommand("next")
      return
    }

    if (lowerCommand.includes("previous slide")) {
      handleSlideCommand("previous")
      return
    }

    if (lowerCommand.includes("stop") || lowerCommand.includes("exit")) {
      speakText("Goodbye! Have a great day.")
      return
    }

    // For general conversation, send to AI
    const event = {
      preventDefault: () => {},
      target: { value: command },
    } as any

    handleInputChange(event)
    setTimeout(() => {
      const form = document.querySelector("form")
      if (form) {
        const submitEvent = new Event("submit", { bubbles: true, cancelable: true })
        form.dispatchEvent(submitEvent)
      }
    }, 100)
  }

  const handleYouTubeCommand = (query: string) => {
    const youtubeUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`
    window.open(youtubeUrl, "_blank")
    speakText(`Opening YouTube search for ${query}`)
  }

  const handleSlideCommand = (direction: "next" | "previous") => {
    // Simulate keyboard events for presentation control
    const event = new KeyboardEvent("keydown", {
      key: direction === "next" ? "ArrowRight" : "ArrowLeft",
      code: direction === "next" ? "ArrowRight" : "ArrowLeft",
      bubbles: true,
    })
    document.dispatchEvent(event)
    speakText(`${direction} slide`)
  }

  const handleTextSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    handleSubmit(e)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
              AI Voice Assistant
            </CardTitle>
            <p className="text-gray-600">Your personal AI companion with voice interaction</p>
          </CardHeader>
        </Card>

        {/* Voice Controls */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <CardContent className="p-6">
            <div className="flex items-center justify-center space-x-4">
              <Button
                onClick={isListening ? stopListening : startListening}
                disabled={!speechSupported}
                size="lg"
                className={`${
                  isListening ? "bg-red-500 hover:bg-red-600 animate-pulse" : "bg-blue-500 hover:bg-blue-600"
                } text-white`}
              >
                {isListening ? <MicOff className="w-6 h-6 mr-2" /> : <Mic className="w-6 h-6 mr-2" />}
                {isListening ? "Stop Listening" : "Start Listening"}
              </Button>

              <Button
                onClick={isSpeaking ? stopSpeaking : () => speakText("Hello! I am your AI assistant.")}
                size="lg"
                variant="outline"
                className="border-2"
              >
                {isSpeaking ? <VolumeX className="w-6 h-6 mr-2" /> : <Volume2 className="w-6 h-6 mr-2" />}
                {isSpeaking ? "Stop Speaking" : "Test Voice"}
              </Button>
            </div>

            {currentTranscript && (
              <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-800">
                  <strong>Listening:</strong> {currentTranscript}
                </p>
              </div>
            )}

            {!speechSupported && (
              <div className="mt-4 p-3 bg-yellow-50 rounded-lg">
                <p className="text-sm text-yellow-800">
                  Speech recognition is not supported in your browser. Please use the text input below.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Play className="w-5 h-5 mr-2" />
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Button
                onClick={() => handleYouTubeCommand("relaxing music")}
                variant="outline"
                className="h-auto p-3 flex flex-col items-center space-y-2"
              >
                <Play className="w-5 h-5" />
                <span className="text-xs">Play Music</span>
              </Button>

              <Button
                onClick={() => handleSlideCommand("next")}
                variant="outline"
                className="h-auto p-3 flex flex-col items-center space-y-2"
              >
                <SkipForward className="w-5 h-5" />
                <span className="text-xs">Next Slide</span>
              </Button>

              <Button
                onClick={() => handleSlideCommand("previous")}
                variant="outline"
                className="h-auto p-3 flex flex-col items-center space-y-2"
              >
                <SkipBack className="w-5 h-5" />
                <span className="text-xs">Prev Slide</span>
              </Button>

              <Button
                onClick={() => speakText("Hello! How can I help you today?")}
                variant="outline"
                className="h-auto p-3 flex flex-col items-center space-y-2"
              >
                <MessageSquare className="w-5 h-5" />
                <span className="text-xs">Greet</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Chat Interface */}
        <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
          <CardHeader>
            <CardTitle className="flex items-center">
              <History className="w-5 h-5 mr-2" />
              Conversation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-96 w-full pr-4">
              <div className="space-y-4">
                {messages.length === 0 && (
                  <div className="text-center text-gray-500 py-8">
                    <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Start a conversation by speaking or typing below</p>
                  </div>
                )}

                {messages.map((message) => (
                  <div key={message.id} className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[80%] p-3 rounded-lg ${
                        message.role === "user" ? "bg-blue-500 text-white" : "bg-gray-100 text-gray-800"
                      }`}
                    >
                      <p className="text-sm">{message.content}</p>
                      <div className="flex items-center justify-between mt-2">
                        <Badge variant="secondary" className="text-xs">
                          {message.role === "user" ? "You" : "Assistant"}
                        </Badge>
                        {message.role === "assistant" && (
                          <Button
                            onClick={() => speakText(message.content)}
                            size="sm"
                            variant="ghost"
                            className="h-6 w-6 p-0"
                          >
                            <Volume2 className="w-3 h-3" />
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                ))}

                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-gray-100 p-3 rounded-lg">
                      <div className="flex space-x-1">
                        <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.1s" }}
                        ></div>
                        <div
                          className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"
                          style={{ animationDelay: "0.2s" }}
                        ></div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </ScrollArea>

            <form onSubmit={handleTextSubmit} className="mt-4 flex space-x-2">
              <Input
                value={input}
                onChange={handleInputChange}
                placeholder="Type your message or use voice input..."
                className="flex-1"
                disabled={isLoading}
              />
              <Button type="submit" disabled={isLoading || !input.trim()}>
                Send
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
