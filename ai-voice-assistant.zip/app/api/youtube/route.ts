export async function POST(req: Request) {
  const { query } = await req.json()

  // Create YouTube search URL
  const youtubeUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`

  return Response.json({
    success: true,
    url: youtubeUrl,
    message: `Opening YouTube search for: ${query}`,
  })
}
