import { streamText } from "ai"
import { openai } from "@ai-sdk/openai"

export const maxDuration = 30

export async function POST(req: Request) {
  const { messages } = await req.json()

  // System prompt to make the AI behave like a personal assistant
  const systemPrompt = `You are a helpful AI voice assistant. You are friendly, concise, and helpful. 
  You can help with:
  - General conversations and questions
  - Playing YouTube videos (when asked to play something)
  - Controlling presentation slides (next/previous)
  - Remembering previous conversations
  - Providing information and assistance
  
  Keep your responses conversational and not too long since they will be spoken aloud.
  If someone asks you to play something on YouTube, acknowledge that you're opening YouTube for them.
  If someone asks about slides, acknowledge the slide navigation.`

  const result = streamText({
    model: openai("gpt-4o-mini"),
    system: systemPrompt,
    messages,
    temperature: 0.7,
    maxTokens: 150,
  })

  return result.toDataStreamResponse()
}
