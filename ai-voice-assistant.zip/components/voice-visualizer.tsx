"use client"

import { useEffect, useRef } from "react"

interface VoiceVisualizerProps {
  isListening: boolean
  audioLevel?: number
}

export function VoiceVisualizer({ isListening, audioLevel = 0 }: VoiceVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const animationRef = useRef<number>()

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const draw = () => {
      const width = canvas.width
      const height = canvas.height

      ctx.clearRect(0, 0, width, height)

      if (isListening) {
        // Draw animated voice visualization
        const centerX = width / 2
        const centerY = height / 2
        const time = Date.now() * 0.005

        for (let i = 0; i < 5; i++) {
          const radius = 20 + i * 15 + Math.sin(time + i) * 10
          const opacity = 0.3 - i * 0.05

          ctx.beginPath()
          ctx.arc(centerX, centerY, radius, 0, Math.PI * 2)
          ctx.strokeStyle = `rgba(59, 130, 246, ${opacity})`
          ctx.lineWidth = 2
          ctx.stroke()
        }
      }

      animationRef.current = requestAnimationFrame(draw)
    }

    draw()

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current)
      }
    }
  }, [isListening])

  return (
    <canvas
      ref={canvasRef}
      width={200}
      height={200}
      className="mx-auto"
      style={{ display: isListening ? "block" : "none" }}
    />
  )
}
